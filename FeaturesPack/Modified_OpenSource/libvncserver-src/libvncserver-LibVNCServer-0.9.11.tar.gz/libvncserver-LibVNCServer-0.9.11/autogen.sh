#!/bin/sh

autoreconf -fiv &&
./configure "$@"
